import java.util.*;
import java.io.*;
/**
 * This program simulates the childrens board game "Uncle Wiggily". The objective of the game is to reach the 100 space.
 * The player must land exactly on the 100 space to win. This program only simulates a game played with one player.
 * 
 * @Ryan Egan
 * HW1
 */
public class UncleWiggily
{
    Scanner in = new Scanner(System.in);
    public String name;
    public int space, turns = 0;
    public Deck gameDeck;
    public int cards = 47;
    
    /**
     * public static void main is used to run the game.
     */
    public static void main(String args[]){
        new UncleWiggily();

    }

    /**
     * Constructor to start the game. The constructor is put into main so that it runs.
     */
    public UncleWiggily(){
        name = findName();
        gameDeck = new Deck();
        game();
    }

    /**
     * A method that finds the name of the user playing the game. The user types their name into the terminal when 
     * prompted with the question "what is your name?" using a scanner.
     * @returns a string. The string is the name that the player typed in.
     */
    public String findName(){
        System.out.println("What is your name?");
        String n = in.nextLine();
        return n;
    }

   /**
    * The major method that is used to run the game. Uses a loop that checks to see if the player is on space 100. Then
    * checks to see where to place the player after he/she picks up a new card. Moves the player to the new space accordingly.
    * Repeats this until the player reaches 100.
    */
    public void game(){

        while(space != 100){
            turns++;
            if(cards == 0){ 
                System.out.println("Deck is out of cards, reshuffling the deck.");
                gameDeck.shuffleDeck();
                cards = 47;
            }
            Card currentCard = gameDeck.selectCard(cards);
            cards--;
            System.out.println(currentCard.cardMessage);

            if(space + currentCard.movement < 100){
                if(space + currentCard.movement <0){
                    space = 0;
                    System.out.println(name + " moves from space " + space + " to 0.");
                }
                else{
                    if(space + currentCard.movement == 58){
                        System.out.println(name + " has found a rabbit hole.");
                        System.out.println(name + " moves from space " + space + " to 83");
                        space = 83;
                    }
                    else{
                        if((space+currentCard.movement == 6) || (space+currentCard.movement == 23) || (space+currentCard.movement == 33) ||  (space+currentCard.movement == 43) ||  (space+currentCard.movement == 80) || (space+currentCard.movement == 90)){
                            space = space + currentCard.movement -3;
                            System.out.println(name + " has to move back three spaces.");
                        }
                        else{
                         
                         System.out.println(name + " moves from space " + space + " to " + (space+currentCard.movement) + ".");
                         space = space + currentCard.movement;
                        }
                    }
                }

            }
            else if(space + currentCard.movement > 100){
                System.out.println(name + " has to stay put.");
                System.out.println(name + " moves from space " + space + " to " + space +".");

            }
            else if((space + currentCard.movement) == 100){
                System.out.println(name + " moves from space " + space + " to 100");
                System.out.println(name + " has won the game.");
                System.out.println("The number of turns in this game was " + turns);
                space = 100;
            }

        }
    }
}

